<?php
echo "PHP está funcionando!";
phpinfo();
?>