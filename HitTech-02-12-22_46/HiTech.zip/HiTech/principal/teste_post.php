<!DOCTYPE html>
<html>
<body>
<h2>Teste POST para enviar_codigo.php</h2>
<form action="enviar_codigo.php" method="POST" target="_blank">
  <input type="email" name="email" value="teste@teste.com" required>
  <button type="submit">Testar PHP</button>
</form>
</body>
</html>